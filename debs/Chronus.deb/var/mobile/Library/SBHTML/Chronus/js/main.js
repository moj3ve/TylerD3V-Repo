function getInfo() {
    // Fetch Date
    var d = new Date;

    // Set Options for Months
    var months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    ];

    // Give Suffix to Dates
    var dates = [
        "0th",
        "1st",
        "2nd",
        "3rd",
        "4th",
        "5th",
        "6th",
        "7th",
        "8th",
        "9th",
        "10th",
        "11th",
        "12th",
        "13th",
        "14th",
        "15th",
        "16th",
        "17th",
        "18th",
        "19th",
        "20th",
        "21st",
        "22nd",
        "23rd",
        "24th",
        "25th",
        "26th",
        "27th",
        "28th",
        "29th",
        "30th",
        "31st"
    ];

    // Grab Date Strings
    var month = months[d.getMonth()];
    var date = dates[d.getDate()];
    var year = d.getFullYear();

    // Grab Time Strings
    var hour = d.getHours();
    var minutes = d.getMinutes();
    var seconds = d.getSeconds();

    // Make Minutes 2 Digits
    if (minutes < "10") {
        minutes = "0" + minutes;
    } else {
        minutes = minutes;
    }

    // Make Seconds 2 Digits
    if (seconds < "10") {
        seconds = "0" + seconds;
    } else {
        seconds = seconds;
    }

    // Determine if AM or PM
    if (hour <= "11") {
        var timeofday = "AM";
    } else {
        var timeofday = "PM";
    }

    // Convert 24 Hour to 12 Hour
    if (hour >= "13") {
        hour = hour - 12;
    } else {
        hour = hour;
    }

    // Display Date and Time
    document.getElementById("date").innerHTML = month + " " + date + ", " + year;
    document.getElementById("time").innerHTML = hour + ":" + minutes + ":" + seconds + " " + timeofday;
}

function init() {
    getInfo();
    setInterval(getInfo, 1000);
}

// Device Stuff
function mainUpdate(type) {
    if (type == "battery") {
        document.getElementById("percent").innerHTML = batteryPercent + "% Remaining";
        document.getElementById("charging").innerHTML = (batteryCharging) ? "Charging" : "Not Charging";
    }
}